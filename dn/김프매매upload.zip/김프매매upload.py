
######업비트 현물- 바이낸스 현물간 김프매매 코드 

#라이브러리
import ccxt                         
import pyupbit
import pandas as pd
import time
import pprint

#개인 모듈
import zamUpbit
import zamBinance


#업비트 엑세스 키 시크릿키
Upbit_access=  #본인의 업비트 엑세스키를 넣으세요.
Upbit_secret= #본인의 업비트 시크릿키를 넣으세요. 

#업비트 객체생성
upbitX = pyupbit.Upbit(Upbit_access, Upbit_secret)

#바이낸스 엑세스 키 시크릿키
Binance_access=   #본인의 바이낸스 엑세스키를 넣으세요.
Binance_secret=   #본인의 바이낸스 시크릿키를 넣으세요.

#바이낸스 객체생성
binanceX = ccxt.binance(config={
    'apiKey': Binance_access, 
    'secret': Binance_secret,
    'enableRateLimit': True,
    'options': {            
        'defaultType': 'spot'
    }
})


#매수코인 선정
ticker = 'BTC/USDT:USDT'

#코인수량 정하기 
amt = 0.001 


# 각 거래소에 맞는 티커명으로 수정.
ticker_bnc=ticker.replace(":USDT","")
ticker_upbit="KRW-"+ticker.replace("/USDT:USDT","")
print("바이낸스 티커명",ticker_bnc)
print("업비트 티커명",ticker_upbit)



#업비트 비트코인 가격구하기
#업비트 캔들 정보 가져온다 -interval (str): "day", "minute1", "minute3", "minute5", "week", "month"  15분은 minute60 4시간 minute240
try:
    df_upbit =zamUpbit.Ohlcv_arbit_upbit(ticker_upbit, 'minute15',count=500)
    print(ticker_bnc,"업비트 15분 캔들정보")
    pprint.pprint(df_upbit)
except Exception as e:
    print(e)

#업비트 현재가격
now_upbit=df_upbit['close'][-1]
print("업비트 현재가격",now_upbit)

#바낸 비트코인 ohlcv구하기 구하기
#(바이낸스객체, 티커명,기간=15m, 30m, 1d)
df_bnc=zamBinance.Ohlcv_arbit_bnc(binanceX, ticker_bnc,'15m')
print("------------------------------")
pprint.pprint(df_bnc)

#바낸 현재가격
now_price_bnc=df_bnc['close'][-1]
print("바낸 현재가격",now_price_bnc)

#환율출력하기
usdkrw=zamBinance.get_usdkrw()
print("현재환율",usdkrw)

#김프값 구하기
# 김프값=(업비트가격-바낸가격*환율)/업비트가격*100= ## %

now_kimp = (now_upbit-now_price_bnc*usdkrw)/now_upbit*100
print("현재김프값",round(now_kimp,1))


###김프값이 0보다 작을때 김프매매시작하고 김프값이 5보다 클때 김프매매 종료하기 

#김프매매 시작조건 
if now_kimp <0:
    #업비트 현물 매수주문+바낸 현물 매도주문
    #지정가설정=바낸현재가격*환율*1.2배
    limit_price_upbit = now_price_bnc*usdkrw*1.2
    #업비트 지정가 매수 주문 코드 
    print("업비트 매수-------")
    zamUpbit.Buy_Limit_arbit(upbitX,ticker_upbit,limit_price_upbit,amt)
    #바낸 시장가 매도 주문 코드 
    print("바낸 현물 매도-------")
    print(binanceX.create_order(ticker_bnc,'market','sell',amt))


#김프매매 종료 조건
if now_kimp >0:
    #업비트 현물 시장가 매도주문+바낸 현물 매수주문
    #업비트 현물 시장가 매도 주문 코드 
    print("업비트 현물 매도-------")
    zamUpbit.Sell_Market_arbit(upbitX,ticker_upbit,amt)
    #바낸 현물 시장가 매수 주문 코드 
    print("바낸 현물 매수-------")
    print(binanceX.create_order(ticker_bnc,'market','buy',amt))





                   





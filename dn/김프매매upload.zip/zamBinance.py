
from cryptography.fernet import Fernet
import requests
import pandas as pd 
import time
import datetime

##업비트와 바이낸스 API의 키를 암호화, 복호화하고 입력해주는 클래스
## (함수랑 개념이 살짝 다른듯하지만 전 함수처럼 사용중)

#암호화 복호화 클래스
class ende:
    #암호를 만들고, 암호를 풀어주는 전용키생성
    def __init__(self, key=None):
        if key is None: # 키가 없다면
            key = Fernet.generate_key() # 키를 생성한다
        self.key = key
        self.f   = Fernet(self.key)

    #숫자를 암호화해주는 함수
    def encrypt(self, data, is_out_string=True):
        if isinstance(data, bytes):
            ou = self.f.encrypt(data) # 바이트형태이면 바로 암호화
        else:
            ou = self.f.encrypt(data.encode('utf-8')) # 인코딩 후 암호화
        if is_out_string is True:
            return ou.decode('utf-8') # 출력이 문자열이면 디코딩 후 반환
        else:
            return ou
    #암호를 풀어주는 함수. 복호화.     
    def decrypt(self, data, is_out_string=True):
        if isinstance(data, bytes):
            ou = self.f.decrypt(data) # 바이트형태이면 바로 복호화
        else:
            ou = self.f.decrypt(data.encode('utf-8')) # 인코딩 후 복호화
        if is_out_string is True:
            return ou.decode('utf-8') # 출력이 문자열이면 디코딩 후 반환
        else:
            return ou


###############바이낸스용
#거래할 코인의 현재가를 가져온다. 첫번째: 바이낸스 객체, 두번째: 코인 티커
def nowprice(binance,Ticker):
    coin_info = binance.fetch_ticker(Ticker)
    coin_price = coin_info['last'] # coin_info['close'] == coin_info['last'] 

    return coin_price


#차익거래용 바이낸스 캔들 정보 만들기 
def Ohlcv_arbit_bnc(binance, Ticker, period):
    btc_ohlcv = binance.fetch_ohlcv(Ticker, period)
    df = pd.DataFrame(btc_ohlcv, columns=['datetime', 'open', 'high', 'low', 'close','volume'])
    df['datetime'] = pd.to_datetime(df['datetime'], unit='ms')
    df.set_index('datetime', inplace=True)
    return df

# 원달러 환율함수
def get_usdkrw():
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}
    url = 'https://quotation-api-cdn.dunamu.com/v1/forex/recent?codes=FRX.KRWUSD'
    exchange =requests.get(url, headers=headers).json()
    return exchange[0]['basePrice']


#선물 숏포지션의 수량을 확인하는 함수
def get_balance_short_bnc(binanceX,ticker_bnc):
    #바이낸스 숏 포지션 진입가격과 수량 확인
    balance = binanceX.fetch_balance(params={"type": "future"})
    for posi in balance['info']['positions']:
        try:
            if posi['symbol'] == ticker_bnc.replace("/", ""):

                if  posi['positionSide']=='SHORT':
                    amt_s = float(posi['positionAmt'])
                    entryPrice_s = float(posi['entryPrice'])

        except Exception as e:
            print("Exception:", e)
    return abs(amt_s)
     



#바낸선물 시장가 숏 오픈
#(티커명,수량)
def short_open_bnc(binanceX,ticker_bnc,amt):
    try:
    
        #구해진 수량으로 바이낸스 선물 숏
        params={'positionSide': 'SHORT'}
        print(binanceX.create_market_sell_order(ticker_bnc,amt,params))

    except Exception as e:
        time.sleep(1.0)
        return short_open_bnc()
    print("바낸선물 숏오픈완료!!!!!!!!!!!!!!!!!!")


#바낸선물 시장가 숏 클로즈
def short_close_bnc(binanceX,ticker_bnc,amt_s):
    try:
        #바이낸스 선물 숏 클로즈. 숏 바이
        params={'positionSide': 'SHORT'}
        print(binanceX.create_market_buy_order(ticker_bnc,abs(amt_s),params))
        ###매매시작과 종료기간을 계산하면 좋은데...어떻게????
    except Exception as e:
        time.sleep(1.0)
        return short_close_bnc()
    print("바낸선물 시장가 숏 클로즈 완료!!!!!!!!!!!!!!!!!!")



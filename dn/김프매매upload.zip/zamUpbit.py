from cryptography.fernet import Fernet
import datetime
import pandas as pd
import time
from pyupbit.request_api import _call_public_api
import numpy
import math




##업비트와 바이낸스 API의 키를 암호화, 복호화하고 입력해주는 클래스
## (함수랑 개념이 살짝 다른듯하지만 전 함수처럼 사용중)

#암호화 복호화 클래스
class ende:
    #암호를 만들고, 암호를 풀어주는 전용키생성
    def __init__(self, key=None):
        if key is None: # 키가 없다면
            key = Fernet.generate_key() # 키를 생성한다
        self.key = key
        self.f   = Fernet(self.key)

    #숫자를 암호화해주는 함수    
    def encrypt(self, data, is_out_string=True):
        if isinstance(data, bytes):
            ou = self.f.encrypt(data) # 바이트형태이면 바로 암호화
        else:
            ou = self.f.encrypt(data.encode('utf-8')) # 인코딩 후 암호화
        if is_out_string is True:
            return ou.decode('utf-8') # 출력이 문자열이면 디코딩 후 반환
        else:
            return ou

    #암호를 풀어주는 함수. 복호화.(키가 저장된 파일.변수명 넣기)     
    def decrypt(self, data, is_out_string=True):
        if isinstance(data, bytes):
            ou = self.f.decrypt(data) # 바이트형태이면 바로 복호화
        else:
            ou = self.f.decrypt(data.encode('utf-8')) # 인코딩 후 복호화
        if is_out_string is True:
            return ou.decode('utf-8') # 출력이 문자열이면 디코딩 후 반환
        else:
            return ou

###
#틱사이즈 보정!! pyupbit에 소수점 2번째까지 지원하는걸로 보여서 추가!
def get_tick_size(price, method="floor"):

    if method == "floor":
        func = math.floor
    elif method == "round":
        func = round 
    else:
        func = math.ceil 

    if price >= 2000000:
        tick_size = func(price / 1000) * 1000
    elif price >= 1000000:
        tick_size = func(price / 500) * 500
    elif price >= 500000:
        tick_size = func(price / 100) * 100
    elif price >= 100000:
        tick_size = func(price / 50) * 50
    elif price >= 10000:
        tick_size = func(price / 10) * 10
    elif price >= 1000:
        tick_size = func(price / 5) * 5
    elif price >= 100:
        tick_size = func(price / 1) * 1
    elif price >= 10:
        tick_size = func(price / 0.1) / 10
    elif price >= 1:
        tick_size = func(price / 0.01) / 100
    elif price >= 0.1:
        tick_size = func(price / 0.001) / 1000
    elif price >= 0.01:
        tick_size = func(price / 0.0001) / 10000
    elif price >= 0.001:
        tick_size = func(price / 0.00001) / 10000
    elif price >= 0.0001:
        tick_size = func(price / 0.000001) / 10000
    else:
        tick_size = func(price / 0.0000001) / 10000


    return tick_size
########업비트용
def get_url_ohlcv(interval):
    """ohlcv 요청을 위한 url을 리턴하는 함수

    Args:
        interval (str): "day", "minute1", "minute3", "minute5", "week", "month"

    Returns:
        str: upbit api url
    """

    if interval in ["day", "days"]:
        url = "https://api.upbit.com/v1/candles/days"
    elif interval in ["minute1", "minutes1"]:
        url = "https://api.upbit.com/v1/candles/minutes/1"
    elif interval in ["minute3", "minutes3"]:
        url = "https://api.upbit.com/v1/candles/minutes/3"
    elif interval in ["minute5", "minutes5"]:
        url = "https://api.upbit.com/v1/candles/minutes/5"
    elif interval in ["minute10", "minutes10"]:
        url = "https://api.upbit.com/v1/candles/minutes/10"
    elif interval in ["minute15", "minutes15"]:
        url = "https://api.upbit.com/v1/candles/minutes/15"
    elif interval in ["minute30", "minutes30"]:
        url = "https://api.upbit.com/v1/candles/minutes/30"
    elif interval in ["minute60", "minutes60"]:
        url = "https://api.upbit.com/v1/candles/minutes/60"
    elif interval in ["minute240", "minutes240"]:
        url = "https://api.upbit.com/v1/candles/minutes/240"
    elif interval in ["week",  "weeks"]:
        url = "https://api.upbit.com/v1/candles/weeks"
    elif interval in ["month", "months"]:
        url = "https://api.upbit.com/v1/candles/months"
    else:
        url = "https://api.upbit.com/v1/candles/days"

    return url



#차익거래용 캔들정보 ohlc 만들기
#원래 pyupbit라이브러리에 있는 함수인데 라이브러리상에선 수정이 안되서 따로 개인모듈에서 수정함.
def Ohlcv_arbit_upbit(ticker="KRW-BTC", interval="day", count=200, to=None,
              period=0.1):
    MAX_CALL_COUNT = 500
    try:
        url = get_url_ohlcv(interval=interval)

        if to is None:
            to = datetime.datetime.now()
        elif isinstance(to, str):
            to = pd.to_datetime(to).to_pydatetime()
        elif isinstance(to, pd._libs.tslibs.timestamps.Timestamp):
            to = to.to_pydatetime()

        #to = to.astimezone(datetime.timezone.utc)

        dfs = []
        count = max(count, 1)
        for pos in range(count, 0, -200):
            query_count = min(MAX_CALL_COUNT, pos)

            to = to.strftime("%Y-%m-%d %H:%M:%S")

            contents, _ = _call_public_api(
                url, market=ticker, count=query_count, to=to)

            dt_list = []
            for x in contents:
                dt = datetime.datetime.strptime(
                    x['candle_date_time_utc'], "%Y-%m-%dT%H:%M:%S")  #미국시간으로 수정해야 바낸 ohlcv와 합칠수 있음.

                dt_list.append(dt)

            df = pd.DataFrame(contents,
                              columns=[
                                  'opening_price',
                                  'high_price',
                                  'low_price',
                                  'trade_price',
                                  'candle_acc_trade_volume'
                                #   ,
                                #   'datetime'
                                  ],
                              index=dt_list)
            # ###새로운열 생성후 인덱스값을 복사하기.
            # df['datetime']=df['candle_date_time']
            df = df.sort_index()
            if df.shape[0] == 0:
                break
            dfs += [df]

            to = datetime.datetime.strptime(
                contents[-1]['candle_date_time_utc'], "%Y-%m-%dT%H:%M:%S")

            if pos > 200:
                time.sleep(period)

        df = pd.concat(dfs).sort_index()
        df = df.rename(columns={"opening_price": "open",
                                "high_price": "high",
                                "low_price": "low",
                                "trade_price": "close",
                                "candle_acc_trade_volume": "volume"
                                })
        # dt = pd.to_datetime(df['datetime'], unit='ms')
        # df.set_index(dt, inplace=True)
        return df
    except Exception:
        return None


#업비트 차익거래용 시장가매수 주문 #타임슬립을 최소로 줄인다. 수량을 리턴한다
#(업비트객체,티커명,매수금액)
def Buy_Market_arbit(upbit,Ticker,Money):
    print(upbit.buy_market_order(Ticker,Money))
    # time.sleep(0.1)
    #내가 가진 해당코인의 수량 잔고 데이터를 가져온다.
    balances = upbit.get_balance(Ticker)
    return balances

#차익거래용 지정가 매수
#차익거래용 지정가매수. 타임슬립을 최소로 줄인다. 티커, 지정가 가격, 수량변수가 필요
def Buy_Limit_arbit(upbit,Ticker,Price,Volume):
    # time.sleep(0.05)
    print(upbit.buy_limit_order(Ticker,get_tick_size(Price),Volume))



#업비트 차익거래용 시장가매도. 타임슬립을 최소로 줄인다. 수량을 리턴한다.
# (업비트객체,티커명,볼륨=수량) 
def Sell_Market_arbit(upbit,Ticker,Volume):
    # time.sleep(0.05)
    print(upbit.sell_market_order(Ticker,Volume))
    # time.sleep(2.0)
    #내가 가진 잔고 데이터를 다 가져온다.
    balances = upbit.get_balances()
    return balances
